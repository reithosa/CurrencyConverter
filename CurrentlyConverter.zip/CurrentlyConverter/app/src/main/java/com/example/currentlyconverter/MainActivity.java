package com.example.currentlyconverter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import okhttp3.*;
import java.io.IOException;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView recyclerView2;
    private DrawerLayout drawerLayout;
    AdapterList adapterList;
    MyAdapter adapter;
    List<DataClass> dataList = new ArrayList<>();
    List<DataForList> dataList2 = new ArrayList<>();
    private String query = "https://openexchangerates.org/api/latest.json?";
    private String app_id = "app_id=1357dbb9a7104be3ab023aa85d00d028";
    private String baseCurrency = "&base=";
    private String namesOfCurrency = "&symbols=GBP,EUR,CNY,RUB,JPY,CHF,CAD,AUD,INR,UAH,KZT&prettyprint=0";

    Map<String, Double> currencies;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Инициализация DrawerLayout
        drawerLayout = findViewById(R.id.drawerLayout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, // Строка для открытия
                R.string.navigation_drawer_close // Строка для закрытия
        );
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        //список для checkbox recyclerView
        dataList2.add(new DataForList(R.drawable.united_states, "USD", false));
        dataList2.add(new DataForList(R.drawable.united_kingdom, "GBP", false));
        dataList2.add(new DataForList(R.drawable.european_union, "EUR", false));
        dataList2.add(new DataForList(R.drawable.china, "CNY", false));
        dataList2.add(new DataForList(R.drawable.russia, "RUB", false));
        dataList2.add(new DataForList(R.drawable.japan, "JPY", false));
        dataList2.add(new DataForList(R.drawable.switzerland, "CHF", false));
        dataList2.add(new DataForList(R.drawable.canada, "CAD", false));
        dataList2.add(new DataForList(R.drawable.australia, "AUD", false));
        dataList2.add(new DataForList(R.drawable.india, "INR", false));
        dataList2.add(new DataForList(R.drawable.ukraine, "UAH", false));
        dataList2.add(new DataForList(R.drawable.kazakhstan, "KZT", false));



        //Ведущая валюта
        EditText editText =  (EditText) findViewById(R.id.MainInputField);
        ImageView imageView = findViewById(R.id.MainImageCurrency);
        TextView textView = findViewById(R.id.MainCurrencyName);
        MyAdapter.OnCurrencyClickListener currencyClickListener = new MyAdapter.OnCurrencyClickListener() {
            @Override
            public void OnCurrencyClick(DataClass dataClass, int position) {
                textView.setText(dataClass.getCurrencyName());
                imageView.setImageResource(dataClass.getImageForCurrency());
            }
        };



        String url = query + app_id + baseCurrency + "USD" + namesOfCurrency;
        Cache cache = new Cache(getCacheDir(),1024 * 1024 * 10);
        OkHttpClient client = new OkHttpClient.Builder().cache(cache).build();

        //запрос
        Request request = new Request.Builder()
                .header("Cache-Control", "public, max-age=86400")
                .url(url)
                .build();
        client.newCall(request).enqueue(
                new Callback() {
                    @Override
                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                        Log.i("Call is Failure","Ошибка");
                    }

                    @Override
                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                        if(response.isSuccessful())
                        {
                            String responseData = response.body().string();
                            Gson gson = new Gson();
                            DataFromAPI dataFromAPI = gson.fromJson(responseData, DataFromAPI.class);
                            currencies = dataFromAPI.getCurrency();
                            if(currencies!=null)Log.d("MyApp", "Список not пуст");
                        }
                    }
                }
        );

        //инициализация recyclerView1
        recyclerView = findViewById(R.id.recyclerView1);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //инициализация adapter1
        adapter = new MyAdapter(dataList, currencyClickListener);
        recyclerView.setAdapter(adapter);

        //инициализация recyclerView2
        recyclerView2 = findViewById(R.id.recyclerView2);
        recyclerView2.setLayoutManager(new LinearLayoutManager(this));
        //инициализация adapter2
        adapterList = new AdapterList(dataList2);
        recyclerView2.setAdapter(adapterList);

        //Обновление по нажатию кнопки
        Button addButton = findViewById(R.id.add_button);
        addButton.setOnClickListener(v -> {
            dataList.clear();
            List<DataForList> selectedItems = adapterList.getSelectedItems(); // Получаем выбранные элементы

            if (selectedItems.isEmpty()) {
                Toast.makeText(this, "Нет выбранных валют", Toast.LENGTH_SHORT).show();
            } else if (currencies == null) {
                Toast.makeText(this, "Данные о валютах не загружены", Toast.LENGTH_SHORT).show();
            } else {
                String p = editText.getText().toString();
                if (p.isEmpty()) {
                    Toast.makeText(this, "Введите сумму", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    for (DataForList item : selectedItems) {
                        String currencyCode = item.getCurrencyNameList();
                        Double exchangeRate = currencies.get(currencyCode);
                        if (exchangeRate != null) {
                            double amount = exchangeRate * Double.parseDouble(p);
                            dataList.add(new DataClass( item.getCurrencyNameList(), textView.getText().toString(),  exchangeRate, amount, item.getImageCurrencyList()));
                        } else {
                            Log.e("CurrencyError", "Курс для валюты " + currencyCode + " не найден");
                        }
                    }
                    runOnUiThread(() -> {
                        adapter.notifyDataSetChanged();
                        Toast.makeText(this, "Добавлено " + selectedItems.size() + " элементов", Toast.LENGTH_SHORT).show();
                    });
                } catch (NumberFormatException e) {
                    runOnUiThread(() -> Toast.makeText(this, "Некорректная сумма", Toast.LENGTH_SHORT).show());
                }
            }
        });
    }
}